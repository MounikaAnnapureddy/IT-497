# IT497 Lab #1 

# Complete the lab below. Send source code and results via ReggieNet 

# R is a statistical programming language # and much more!!! 

# We will start with the basics 

# You can use R like a calculator 
x <- 1 
y <- 2 
z <- x + y 
z  
str(z) 


# First, let’s read in some heart attack payment data. 

# This data comes from The United States Department of Health and # Human Services (HHS) 

# http://www.healthdata.gov/dataset/heart-attack-payment-national 

# I have downloaded a copy of the data to ISU's sever to make it
# simple 

df <- read.table("http://www.itk.ilstu.edu/faculty/jrwolf/hacosts.csv", header = TRUE, sep = ",")  

# In the above df is the name of our data frame. A data frame is used 
# for storing  data tables. 

# It is a list of vectors of equal length. 

# We can display the contents of our data frame by typing its name and selection  # run. 

df 




##
# The top line of the table is called the # header.  The header contains the column names. 
##

names(df) 
head(df) 
head(df, 10) 
tail(df) 
tail(df, 8) 
head(df, 23) 
nrow(df) 
ncol(df) 
str(df) 

## 
# We can access specific data frame columns by name 
##

df$State 
# When accessing columns by name, we use the data frame 
# name followed       
# by the $ symbol and the column name 

df$Cost 
mean(df$Cost) # We can perform operations on specific columns min(df$Cost) 
max(df$Cost) 
sd(df$Cost)  

# Each horizontal line below the header is called a data row.
# Each data element of a row is called a cell. 

# We can also access columns, rows and even cells 
# by location

df$Cost[2] # This returns the cost cell in the second row 
df$Cost[2:5] # This returns the cost cells in 
# rows 2 through 5 
df[5,] # This returns all of the columns in row 5 
df[1:5,] # This returns all of the columns 
# in rows 1 through 5 
df[5,1] # This returns the data in row 5 column 1 
df[5,2] # This returns the data in row 5 column 2 


# We can find the minimum and maximum values in each column 

which.min(df$Cost) # this returns the row of the minimum value 
which.max(df$Cost) # this returns the row of the maximum value 
df[which.min(df$Cost),] # this returns the row of min 
# value 
df[which.max(df$Cost),] # this returns the row of 
# maximum value 


# We can sort the data in our data frame by column 
df <- df[order(df$Cost),] # the default is ascending head(df)  

low <- df[1:5,] # This assigns the data from the first 5 rows to a 
# dataframe named low 
low # prints low

df <- df[order(-df$Cost), ] # to sort in descending order head(df)  

high <- df[1:5,]  # This assigns the data from the first 5 rows  
# to a data frame named high 

high # prints high

##
############################### 
##
# Let’s move a bit faster 
# read in fitbit data 
df <-read.csv("http://www.itk.ilstu.edu/faculty/jrwolf/fitbitstats.csv" , stringsAsFactors=F) 
# Convert the Steps to numeric 
df$Steps <- as.numeric(df$Steps) 
str(df)
# Look at the structure of your data frame str(df) 
# Check minimums and maximums 
which.min(df$Steps) 
which.max(df$Steps) 
df[which.min(df$Steps), ] 
df[which.max(df$Steps), ] 






##
#YOUR TURN 
##
# Using the fitbit data answer the following 
# 1. Look at the first 12 rows of data 
head(df,12)
# 2. Look at the last 12 rows of data 
tail(df,12)
# 3. Find the total number of rows in the data 
nrow(df)
# 4. Find the total number or columns in the data 
ncol(df)
# 5. Show the distance for the 120th row
df$Distance[120] #5
# 6. Sow the entire 87th row 
df[87,]
# 7 show only the 2nd column for the 3rd and 4th row 
df[3:4,2]
# 8. Send me your code and your answers 1-7 via Reggienet 
